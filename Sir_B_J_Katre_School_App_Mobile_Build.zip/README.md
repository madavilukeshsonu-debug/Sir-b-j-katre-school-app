# Sir B. J. Katre School — Starter Project

This is a starter scaffold for **Sir B. J. Katre Model English Primary School**.

Included:
- `flutter_app/`: Flutter Android app starter with a school dashboard UI.
- `web_admin/`: responsive browser-based admin dashboard prototype.
- `docs/`: scope and next steps.

## Important
This is a **starter prototype**, not a production-ready app/APK. It does not yet have a live database, secure authentication, push notifications, or a payment gateway. Those require setup, credentials, implementation, and testing.

## Run the Flutter app
1. Install Flutter SDK and Android Studio.
2. In a terminal, run:
   ```bash
   cd flutter_app
   flutter create .
   ```
   Keep/replace the generated `lib/main.dart` with the included file if `flutter create` overwrites it.
3. Run:
   ```bash
   flutter pub get
   flutter run
   ```
4. To build an APK after testing:
   ```bash
   flutter build apk --release
   ```
The build must be run on a machine with Flutter/Android SDK installed.

## Open the web admin prototype
Open `web_admin/index.html` in a browser. It is a visual prototype with demo numbers only; data is not saved or synced.
