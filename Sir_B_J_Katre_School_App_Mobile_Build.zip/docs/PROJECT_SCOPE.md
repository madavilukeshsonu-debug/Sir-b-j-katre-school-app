# Project scope

## Roles
- Admin / Principal
- Authorized Teacher
- Student
- Parent
- Staff

## Core modules
- Student and staff directory
- Attendance
- Homework
- Timetable
- Exams and results
- Fee ledger, receipts, and payment gateway integration
- Notices and reports
- English, Hindi, Marathi localization

## Before production
1. Confirm school legal/official name and logo permission.
2. Define who can view/edit each data type.
3. Select backend and hosting (e.g., Firebase or a custom API/database).
4. Implement authentication, role-based access, backups, and audit logs.
5. Configure payment gateway using the school's verified merchant account.
6. Test on Android devices and browsers; validate privacy and data handling.
7. Build and sign the release APK.
