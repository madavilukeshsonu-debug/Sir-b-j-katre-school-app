import 'package:flutter/material.dart';

void main() => runApp(const KatreSchoolApp());

class KatreSchoolApp extends StatelessWidget {
  const KatreSchoolApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Sir B. J. Katre School',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF123B68)),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF4F7FB),
      ),
      home: const SchoolHomePage(),
    );
  }
}

class SchoolHomePage extends StatelessWidget {
  const SchoolHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final tiles = <_Feature>[
      _Feature('Students', Icons.school_rounded, const Color(0xFF2463A6)),
      _Feature('Teachers', Icons.cast_for_education_rounded, const Color(0xFF138A72)),
      _Feature('All Staff', Icons.groups_rounded, const Color(0xFF8054B5)),
      _Feature('Attendance', Icons.fact_check_rounded, const Color(0xFFE59A28)),
      _Feature('Homework', Icons.menu_book_rounded, const Color(0xFFDA6B45)),
      _Feature('Fees', Icons.account_balance_wallet_rounded, const Color(0xFF2C7A4B)),
      _Feature('Results', Icons.workspace_premium_rounded, const Color(0xFF5369C8)),
      _Feature('Notices', Icons.campaign_rounded, const Color(0xFFB94D70)),
      _Feature('Timetable', Icons.calendar_month_rounded, const Color(0xFF287E9C)),
      _Feature('Reports', Icons.bar_chart_rounded, const Color(0xFF525B6B)),
    ];

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF123B68),
        foregroundColor: Colors.white,
        title: const Text('Sir B. J. Katre School',
            style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18)),
        actions: [
          IconButton(
            tooltip: 'Notifications',
            onPressed: () => _message(context, 'Notifications will be connected later.'),
            icon: const Icon(Icons.notifications_none_rounded),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF123B68), Color(0xFF2878B9)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(22),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.menu_book_rounded, color: Colors.white, size: 36),
                  SizedBox(height: 12),
                  Text('SIR B. J. KATRE MODEL\\nENGLISH PRIMARY SCHOOL',
                      style: TextStyle(color: Colors.white, fontSize: 19,
                          fontWeight: FontWeight.w800, height: 1.25)),
                  SizedBox(height: 6),
                  Text('PANDHARI  •  KG 1 TO STD. 7',
                      style: TextStyle(color: Color(0xFFDCEBFA), fontSize: 12,
                          letterSpacing: 1.0)),
                ],
              ),
            ),
            const SizedBox(height: 18),
            const Text('School Overview',
                style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
            const SizedBox(height: 12),
            const Row(children: [
              Expanded(child: _StatCard(label: 'Students', value: '—', icon: Icons.school)),
              SizedBox(width: 10),
              Expanded(child: _StatCard(label: 'Staff', value: '—', icon: Icons.groups)),
              SizedBox(width: 10),
              Expanded(child: _StatCard(label: 'Attendance', value: '—', icon: Icons.fact_check)),
            ]),
            const SizedBox(height: 22),
            const Text('Quick Access',
                style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
            const SizedBox(height: 12),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: tiles.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12,
                childAspectRatio: 1.25,
              ),
              itemBuilder: (context, i) => InkWell(
                borderRadius: BorderRadius.circular(18),
                onTap: () => _message(context,
                    '${tiles[i].label} module is a prototype. Database and login setup are still required.'),
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(18),
                    boxShadow: const [BoxShadow(color: Color(0x0D123B68),
                        blurRadius: 14, offset: Offset(0, 5))],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      CircleAvatar(
                        backgroundColor: tiles[i].color.withOpacity(.12),
                        foregroundColor: tiles[i].color,
                        child: Icon(tiles[i].icon),
                      ),
                      Text(tiles[i].label,
                          style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                      const Icon(Icons.arrow_forward_rounded, size: 18, color: Color(0xFF8793A4)),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 18),
            const Text('Languages: English • हिंदी • मराठी',
                textAlign: TextAlign.center,
                style: TextStyle(color: Color(0xFF69788A), fontSize: 12)),
            const SizedBox(height: 8),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: 0,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_rounded), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.notifications_none), label: 'Notices'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profile'),
        ],
        onDestinationSelected: (index) => _message(context,
            ['Home', 'Notices', 'Profile'][index] + ' screen prototype'),
      ),
    );
  }

  static void _message(BuildContext context, String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }
}

class _Feature {
  final String label;
  final IconData icon;
  final Color color;
  const _Feature(this.label, this.icon, this.color);
}

class _StatCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  const _StatCard({required this.label, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
    child: Column(children: [
      Icon(icon, color: const Color(0xFF2463A6), size: 22),
      const SizedBox(height: 8),
      Text(value, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 19)),
      Text(label, style: const TextStyle(color: Color(0xFF69788A), fontSize: 11)),
    ]),
  );
}
